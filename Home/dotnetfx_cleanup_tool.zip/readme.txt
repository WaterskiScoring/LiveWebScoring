README FOR INSTALLATION CLEANUP UTILITY

WHAT IS THE INSTALLATION CLEANUP UTILITY?
The Installation Cleanup Utility is designed to allow you to manually remove products from your computer in the event of a failed installation or uninstallation. Although the Windows Installer is designed to be very robust, it is possible for Windows Installer to become damaged if:

 - Installing or uninstalling a specific product consistently fails on your computer and you want to remove any leftover files and settings before trying again
 - Your computer's registry becomes corrupt
 - Someone inadvertantly changes a registry setting used by the Windows Installer, resulting in a problem
 - The installation of a program that uses Windows Installer (for example, .NET Framework 1.0, 1.1 or 2.0) is interrupted

WHAT OPERATING SYSTEMS ARE SUPPORTED?
This version of the Installation Cleanup Utility will work properly on all Windows operating systems beginning with Windows 95. In order to clean up Windows Installer-based products, you must have a version of Windows Installer installed on your computer.

WHAT FILES ARE PART OF THE INSTALLATION CLEANUP UTILITY?
This version of the Installation Cleanup Utility comes with the following files

   cleanup.exe   The main executable file for the Installation Cleanup Utility

   cleanup.ini   A settings file that describes what products are listed in the Installation Cleanup Utility user interface; it also describes what actions to take to clean up each product

   msizap.exe    Command line utility that removes Windows Installer settings from a computer; this is useful in many setup failure scenarios, such as when product uninstall fails and Windows Installer still detects that a product is installed but the Add/Remove Programs entry is no longer present

   readme.txt    This file

   unicows.dll   Helper DLL that allows the Installation Cleanup Utility to work correctly on non-Unicode operating systems such as Windows 95, Windows 98 and Windows ME

HOW DO I USE THE INSTALLATION CLEANUP UTILITY?
When you download the Installation Cleanup Utility, simply run it. It requires no installation program. 

When you do this, a dialog box appears with the following message:

   Warning: continuing further will make permanent changes to your system.
   You will need to reinstall any products that you choose to cleanup. If you do
   not want to proceed, press the 'Exit' button now.

The dialog box lists all programs that can be cleaned up with this version of the Installation Cleanup Utility. installed on your computer that use Windows Installer.

There are four buttons:

   View Readme  Displays this readme file.

   View Log     Displays the Installation Cleanup Utility log file.

   Cleanup Now  Cleans up the settings associated with the selected program.

   Exit         Exits the Installation Cleanup Utility.

If you click Cleanup Now, the Installation Cleanup Utility will remove all file, registry, and Windows Installer information associated with the selected programs, including the entries for the programs in the Add/Remove Programs control panel. The information that will be removed is listed in the accompanying file cleanup.ini. If you remove the settings for a product that is currently installed on your computer, the product will no longer be able to add or remove components or to repair itself; you must reinstall the product in order to use them again.

